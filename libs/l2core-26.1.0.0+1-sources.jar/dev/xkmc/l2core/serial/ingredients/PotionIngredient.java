package dev.xkmc.l2core.serial.ingredients;

import dev.xkmc.l2core.init.L2LibReg;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.display.SlotDisplay;
import net.neoforged.neoforge.common.crafting.ICustomIngredient;
import net.neoforged.neoforge.common.crafting.IngredientType;

import java.util.stream.Stream;

public record PotionIngredient(Holder<Potion> potion) implements ICustomIngredient {

	public static Ingredient of(Holder<Potion> potion) {
		return new PotionIngredient(potion).toVanilla();
	}

	@Override
	public SlotDisplay display() {
		var patch = DataComponentPatch.builder()
				.set(DataComponents.POTION_CONTENTS, new PotionContents(potion))
				.build();
		return new SlotDisplay.ItemStackSlotDisplay(new ItemStackTemplate(Items.POTION, patch));
	}

	@Override
	public Stream<Holder<Item>> items() {
		return Stream.of(Items.POTION.builtInRegistryHolder());
	}

	@Override
	public boolean isSimple() {
		return false;
	}

	@Override
	public IngredientType<?> getType() {
		return L2LibReg.ING_POTION.get();
	}

	public boolean test(ItemStack stack) {
		PotionContents val = stack.get(DataComponents.POTION_CONTENTS);
		return val != null && val.is(potion);
	}

}
